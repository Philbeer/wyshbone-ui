import { pgTable, text, serial, integer, boolean, timestamp, decimal, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // pub, restaurant, retail, etc.
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  city: text("city"),
  postcode: text("postcode"),
  country: text("country").default("UK"),
  contactPerson: text("contact_person"),
  status: text("status").default("active"), // active, inactive, pending
  creditLimit: decimal("credit_limit", { precision: 10, scale: 2 }),
  paymentTerms: text("payment_terms"),
  deliveryInstructions: text("delivery_instructions"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // beer, cider, spirits, etc.
  style: text("style"), // IPA, Stout, Lager, etc.
  abv: decimal("abv", { precision: 4, scale: 2 }),
  description: text("description"),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }),
  containerSize: text("container_size"), // 50L, 30L, 500ml, etc.
  status: text("status").default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerId: integer("customer_id").references(() => customers.id),
  status: text("status").default("pending"), // pending, confirmed, delivered, cancelled
  orderDate: timestamp("order_date").defaultNow(),
  deliveryDate: timestamp("delivery_date"),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").references(() => orders.id),
  productId: integer("product_id").references(() => products.id),
  quantity: integer("quantity").notNull(),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }),
});

export const productionBatches = pgTable("production_batches", {
  id: serial("id").primaryKey(),
  batchNumber: text("batch_number").notNull().unique(),
  productId: integer("product_id").references(() => products.id),
  status: text("status").default("brewing"), // brewing, fermenting, conditioning, packaging, finished
  startDate: timestamp("start_date").defaultNow(),
  estimatedFinishDate: timestamp("estimated_finish_date"),
  actualFinishDate: timestamp("actual_finish_date"),
  volume: decimal("volume", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const containers = pgTable("containers", {
  id: serial("id").primaryKey(),
  containerId: text("container_id").notNull().unique(),
  type: text("type").notNull(), // keg, cask, bottle, can
  size: text("size").notNull(), // 50L, 30L, 500ml, etc.
  status: text("status").default("in_stock"), // in_stock, out_for_delivery, delivered, overdue, empty
  productId: integer("product_id").references(() => products.id),
  batchId: integer("batch_id").references(() => productionBatches.id),
  customerId: integer("customer_id").references(() => customers.id),
  location: text("location"),
  deliveryDate: timestamp("delivery_date"),
  expectedReturnDate: timestamp("expected_return_date"),
  actualReturnDate: timestamp("actual_return_date"),
  qrCode: text("qr_code"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  itemName: text("item_name").notNull(),
  itemType: text("item_type").notNull(), // raw_material, finished_product, packaging
  currentStock: decimal("current_stock", { precision: 10, scale: 2 }),
  minimumStock: decimal("minimum_stock", { precision: 10, scale: 2 }),
  unit: text("unit").notNull(), // kg, L, pieces, etc.
  location: text("location"),
  supplier: text("supplier"),
  cost: decimal("cost", { precision: 10, scale: 2 }),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const salesVisits = pgTable("sales_visits", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customers.id),
  scheduledDate: timestamp("scheduled_date").notNull(),
  actualDate: timestamp("actual_date"),
  status: text("status").default("scheduled"), // scheduled, completed, cancelled
  notes: text("notes"),
  outcomes: text("outcomes"),
  followUpRequired: boolean("follow_up_required").default(false),
  followUpDate: timestamp("follow_up_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const dutyCalculations = pgTable("duty_calculations", {
  id: serial("id").primaryKey(),
  period: text("period").notNull(), // YYYY-MM format
  productId: integer("product_id").references(() => products.id),
  volumeProduced: decimal("volume_produced", { precision: 10, scale: 2 }),
  volumeSold: decimal("volume_sold", { precision: 10, scale: 2 }),
  dutyRate: decimal("duty_rate", { precision: 10, scale: 4 }),
  dutyOwed: decimal("duty_owed", { precision: 10, scale: 2 }),
  ullage: decimal("ullage", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const customersRelations = relations(customers, ({ many }) => ({
  orders: many(orders),
  containers: many(containers),
  salesVisits: many(salesVisits),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(customers, {
    fields: [orders.customerId],
    references: [customers.id],
  }),
  items: many(orderItems),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
}));

export const productsRelations = relations(products, ({ many }) => ({
  orderItems: many(orderItems),
  batches: many(productionBatches),
  containers: many(containers),
  dutyCalculations: many(dutyCalculations),
}));

export const productionBatchesRelations = relations(productionBatches, ({ one, many }) => ({
  product: one(products, {
    fields: [productionBatches.productId],
    references: [products.id],
  }),
  containers: many(containers),
}));

export const containersRelations = relations(containers, ({ one }) => ({
  product: one(products, {
    fields: [containers.productId],
    references: [products.id],
  }),
  batch: one(productionBatches, {
    fields: [containers.batchId],
    references: [productionBatches.id],
  }),
  customer: one(customers, {
    fields: [containers.customerId],
    references: [customers.id],
  }),
}));

export const salesVisitsRelations = relations(salesVisits, ({ one }) => ({
  customer: one(customers, {
    fields: [salesVisits.customerId],
    references: [customers.id],
  }),
}));

export const dutyCalculationsRelations = relations(dutyCalculations, ({ one }) => ({
  product: one(products, {
    fields: [dutyCalculations.productId],
    references: [products.id],
  }),
}));

// Insert schemas
export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

export const insertProductionBatchSchema = createInsertSchema(productionBatches).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertContainerSchema = createInsertSchema(containers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  updatedAt: true,
});

export const insertSalesVisitSchema = createInsertSchema(salesVisits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDutyCalculationSchema = createInsertSchema(dutyCalculations).omit({
  id: true,
  createdAt: true,
});

// Types
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

export type ProductionBatch = typeof productionBatches.$inferSelect;
export type InsertProductionBatch = z.infer<typeof insertProductionBatchSchema>;

export type Container = typeof containers.$inferSelect;
export type InsertContainer = z.infer<typeof insertContainerSchema>;

export type Inventory = typeof inventory.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;

export type SalesVisit = typeof salesVisits.$inferSelect;
export type InsertSalesVisit = z.infer<typeof insertSalesVisitSchema>;

export type DutyCalculation = typeof dutyCalculations.$inferSelect;
export type InsertDutyCalculation = z.infer<typeof insertDutyCalculationSchema>;
