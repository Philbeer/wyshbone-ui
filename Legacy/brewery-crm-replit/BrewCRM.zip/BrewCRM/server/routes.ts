import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertCustomerSchema, insertOrderSchema, insertProductSchema, insertProductionBatchSchema, insertContainerSchema, insertInventorySchema, insertSalesVisitSchema, insertDutyCalculationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard routes
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  app.get("/api/dashboard/sales-data", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      const salesData = await storage.getSalesData(days);
      res.json(salesData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sales data" });
    }
  });

  // Customer routes
  app.get("/api/customers", async (req, res) => {
    try {
      const customers = await storage.getCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Search query is required" });
      }
      const customers = await storage.searchCustomers(query);
      res.json(customers);
    } catch (error) {
      res.status(500).json({ error: "Failed to search customers" });
    }
  });

  app.get("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const customer = await storage.getCustomer(id);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch customer" });
    }
  });

  app.post("/api/customers", async (req, res) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(validatedData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid customer data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create customer" });
    }
  });

  app.put("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(id, validatedData);
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid customer data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update customer" });
    }
  });

  app.delete("/api/customers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCustomer(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete customer" });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const validatedData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(validatedData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid product data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductSchema.partial().parse(req.body);
      const product = await storage.updateProduct(id, validatedData);
      res.json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid product data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProduct(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Order routes
  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });

  app.get("/api/orders/:id/items", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const items = await storage.getOrderItems(id);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch order items" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid order data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  app.put("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertOrderSchema.partial().parse(req.body);
      const order = await storage.updateOrder(id, validatedData);
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid order data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update order" });
    }
  });

  app.delete("/api/orders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteOrder(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete order" });
    }
  });

  // Production Batch routes
  app.get("/api/production-batches", async (req, res) => {
    try {
      const batches = await storage.getProductionBatches();
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch production batches" });
    }
  });

  app.get("/api/production-batches/active", async (req, res) => {
    try {
      const batches = await storage.getActiveBatches();
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch active batches" });
    }
  });

  app.get("/api/production-batches/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const batch = await storage.getProductionBatch(id);
      if (!batch) {
        return res.status(404).json({ error: "Production batch not found" });
      }
      res.json(batch);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch production batch" });
    }
  });

  app.post("/api/production-batches", async (req, res) => {
    try {
      const validatedData = insertProductionBatchSchema.parse(req.body);
      const batch = await storage.createProductionBatch(validatedData);
      res.status(201).json(batch);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid production batch data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create production batch" });
    }
  });

  app.put("/api/production-batches/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertProductionBatchSchema.partial().parse(req.body);
      const batch = await storage.updateProductionBatch(id, validatedData);
      res.json(batch);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid production batch data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update production batch" });
    }
  });

  app.delete("/api/production-batches/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProductionBatch(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete production batch" });
    }
  });

  // Container routes
  app.get("/api/containers", async (req, res) => {
    try {
      const containers = await storage.getContainers();
      res.json(containers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch containers" });
    }
  });

  app.get("/api/containers/overdue", async (req, res) => {
    try {
      const containers = await storage.getOverdueContainers();
      res.json(containers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch overdue containers" });
    }
  });

  app.get("/api/containers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const container = await storage.getContainer(id);
      if (!container) {
        return res.status(404).json({ error: "Container not found" });
      }
      res.json(container);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch container" });
    }
  });

  app.get("/api/containers/track/:containerId", async (req, res) => {
    try {
      const containerId = req.params.containerId;
      const container = await storage.getContainerByContainerId(containerId);
      if (!container) {
        return res.status(404).json({ error: "Container not found" });
      }
      res.json(container);
    } catch (error) {
      res.status(500).json({ error: "Failed to track container" });
    }
  });

  app.post("/api/containers", async (req, res) => {
    try {
      const validatedData = insertContainerSchema.parse(req.body);
      const container = await storage.createContainer(validatedData);
      res.status(201).json(container);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid container data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create container" });
    }
  });

  app.put("/api/containers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertContainerSchema.partial().parse(req.body);
      const container = await storage.updateContainer(id, validatedData);
      res.json(container);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid container data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update container" });
    }
  });

  app.delete("/api/containers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteContainer(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete container" });
    }
  });

  // Inventory routes
  app.get("/api/inventory", async (req, res) => {
    try {
      const inventory = await storage.getInventory();
      res.json(inventory);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch inventory" });
    }
  });

  app.get("/api/inventory/low-stock", async (req, res) => {
    try {
      const items = await storage.getLowStockItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch low stock items" });
    }
  });

  app.post("/api/inventory", async (req, res) => {
    try {
      const validatedData = insertInventorySchema.parse(req.body);
      const item = await storage.createInventoryItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid inventory data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create inventory item" });
    }
  });

  app.put("/api/inventory/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertInventorySchema.partial().parse(req.body);
      const item = await storage.updateInventoryItem(id, validatedData);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid inventory data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update inventory item" });
    }
  });

  app.delete("/api/inventory/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteInventoryItem(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete inventory item" });
    }
  });

  // Sales Visit routes
  app.get("/api/sales-visits", async (req, res) => {
    try {
      const visits = await storage.getSalesVisits();
      res.json(visits);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sales visits" });
    }
  });

  app.get("/api/sales-visits/upcoming", async (req, res) => {
    try {
      const visits = await storage.getUpcomingSalesVisits();
      res.json(visits);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch upcoming sales visits" });
    }
  });

  app.post("/api/sales-visits", async (req, res) => {
    try {
      const validatedData = insertSalesVisitSchema.parse(req.body);
      const visit = await storage.createSalesVisit(validatedData);
      res.status(201).json(visit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid sales visit data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create sales visit" });
    }
  });

  app.put("/api/sales-visits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertSalesVisitSchema.partial().parse(req.body);
      const visit = await storage.updateSalesVisit(id, validatedData);
      res.json(visit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid sales visit data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update sales visit" });
    }
  });

  app.delete("/api/sales-visits/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteSalesVisit(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete sales visit" });
    }
  });

  // Duty Calculation routes
  app.get("/api/duty-calculations", async (req, res) => {
    try {
      const calculations = await storage.getDutyCalculations();
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch duty calculations" });
    }
  });

  app.get("/api/duty-calculations/period/:period", async (req, res) => {
    try {
      const period = req.params.period;
      const calculations = await storage.getDutyCalculationsByPeriod(period);
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch duty calculations for period" });
    }
  });

  app.post("/api/duty-calculations", async (req, res) => {
    try {
      const validatedData = insertDutyCalculationSchema.parse(req.body);
      const calculation = await storage.createDutyCalculation(validatedData);
      res.status(201).json(calculation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid duty calculation data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create duty calculation" });
    }
  });

  app.put("/api/duty-calculations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertDutyCalculationSchema.partial().parse(req.body);
      const calculation = await storage.updateDutyCalculation(id, validatedData);
      res.json(calculation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid duty calculation data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to update duty calculation" });
    }
  });

  app.delete("/api/duty-calculations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteDutyCalculation(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete duty calculation" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
