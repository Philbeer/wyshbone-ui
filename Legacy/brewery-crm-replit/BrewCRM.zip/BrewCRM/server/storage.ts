import { 
  customers, 
  products, 
  orders, 
  orderItems, 
  productionBatches, 
  containers, 
  inventory, 
  salesVisits, 
  dutyCalculations,
  type Customer, 
  type InsertCustomer,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type ProductionBatch,
  type InsertProductionBatch,
  type Container,
  type InsertContainer,
  type Inventory,
  type InsertInventory,
  type SalesVisit,
  type InsertSalesVisit,
  type DutyCalculation,
  type InsertDutyCalculation
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, or, like, gte, lte, count, sum } from "drizzle-orm";

export interface IStorage {
  // Customers
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer>;
  deleteCustomer(id: number): Promise<void>;
  searchCustomers(query: string): Promise<Customer[]>;

  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByCustomer(customerId: number): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order>;
  deleteOrder(id: number): Promise<void>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;

  // Production Batches
  getProductionBatches(): Promise<ProductionBatch[]>;
  getProductionBatch(id: number): Promise<ProductionBatch | undefined>;
  createProductionBatch(batch: InsertProductionBatch): Promise<ProductionBatch>;
  updateProductionBatch(id: number, batch: Partial<InsertProductionBatch>): Promise<ProductionBatch>;
  deleteProductionBatch(id: number): Promise<void>;
  getActiveBatches(): Promise<ProductionBatch[]>;

  // Containers
  getContainers(): Promise<Container[]>;
  getContainer(id: number): Promise<Container | undefined>;
  getContainerByContainerId(containerId: string): Promise<Container | undefined>;
  createContainer(container: InsertContainer): Promise<Container>;
  updateContainer(id: number, container: Partial<InsertContainer>): Promise<Container>;
  deleteContainer(id: number): Promise<void>;
  getOverdueContainers(): Promise<Container[]>;
  getContainersByCustomer(customerId: number): Promise<Container[]>;

  // Inventory
  getInventory(): Promise<Inventory[]>;
  getInventoryItem(id: number): Promise<Inventory | undefined>;
  createInventoryItem(item: InsertInventory): Promise<Inventory>;
  updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory>;
  deleteInventoryItem(id: number): Promise<void>;
  getLowStockItems(): Promise<Inventory[]>;

  // Sales Visits
  getSalesVisits(): Promise<SalesVisit[]>;
  getSalesVisit(id: number): Promise<SalesVisit | undefined>;
  getSalesVisitsByCustomer(customerId: number): Promise<SalesVisit[]>;
  createSalesVisit(visit: InsertSalesVisit): Promise<SalesVisit>;
  updateSalesVisit(id: number, visit: Partial<InsertSalesVisit>): Promise<SalesVisit>;
  deleteSalesVisit(id: number): Promise<void>;
  getUpcomingSalesVisits(): Promise<SalesVisit[]>;

  // Duty Calculations
  getDutyCalculations(): Promise<DutyCalculation[]>;
  getDutyCalculation(id: number): Promise<DutyCalculation | undefined>;
  createDutyCalculation(calculation: InsertDutyCalculation): Promise<DutyCalculation>;
  updateDutyCalculation(id: number, calculation: Partial<InsertDutyCalculation>): Promise<DutyCalculation>;
  deleteDutyCalculation(id: number): Promise<void>;
  getDutyCalculationsByPeriod(period: string): Promise<DutyCalculation[]>;

  // Analytics
  getDashboardMetrics(): Promise<{
    totalCustomers: number;
    activeBatches: number;
    monthlyRevenue: number;
    containersOut: number;
    overdueContainers: number;
  }>;
  getSalesData(days: number): Promise<{ date: string; amount: number }[]>;
}

export class DatabaseStorage implements IStorage {
  // Customers
  async getCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(asc(customers.name));
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer || undefined;
  }

  async createCustomer(customer: InsertCustomer): Promise<Customer> {
    const [newCustomer] = await db.insert(customers).values(customer).returning();
    return newCustomer;
  }

  async updateCustomer(id: number, customer: Partial<InsertCustomer>): Promise<Customer> {
    const [updatedCustomer] = await db
      .update(customers)
      .set({ ...customer, updatedAt: new Date() })
      .where(eq(customers.id, id))
      .returning();
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<void> {
    await db.delete(customers).where(eq(customers.id, id));
  }

  async searchCustomers(query: string): Promise<Customer[]> {
    return await db
      .select()
      .from(customers)
      .where(
        or(
          like(customers.name, `%${query}%`),
          like(customers.email, `%${query}%`),
          like(customers.city, `%${query}%`)
        )
      )
      .orderBy(asc(customers.name));
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(asc(products.name));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product> {
    const [updatedProduct] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return await db.select().from(orders).orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order || undefined;
  }

  async getOrdersByCustomer(customerId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.customerId, customerId))
      .orderBy(desc(orders.createdAt));
  }

  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async updateOrder(id: number, order: Partial<InsertOrder>): Promise<Order> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ ...order, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  async deleteOrder(id: number): Promise<void> {
    await db.delete(orders).where(eq(orders.id, id));
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem> {
    const [newOrderItem] = await db.insert(orderItems).values(orderItem).returning();
    return newOrderItem;
  }

  // Production Batches
  async getProductionBatches(): Promise<ProductionBatch[]> {
    return await db.select().from(productionBatches).orderBy(desc(productionBatches.createdAt));
  }

  async getProductionBatch(id: number): Promise<ProductionBatch | undefined> {
    const [batch] = await db.select().from(productionBatches).where(eq(productionBatches.id, id));
    return batch || undefined;
  }

  async createProductionBatch(batch: InsertProductionBatch): Promise<ProductionBatch> {
    const [newBatch] = await db.insert(productionBatches).values(batch).returning();
    return newBatch;
  }

  async updateProductionBatch(id: number, batch: Partial<InsertProductionBatch>): Promise<ProductionBatch> {
    const [updatedBatch] = await db
      .update(productionBatches)
      .set({ ...batch, updatedAt: new Date() })
      .where(eq(productionBatches.id, id))
      .returning();
    return updatedBatch;
  }

  async deleteProductionBatch(id: number): Promise<void> {
    await db.delete(productionBatches).where(eq(productionBatches.id, id));
  }

  async getActiveBatches(): Promise<ProductionBatch[]> {
    return await db
      .select()
      .from(productionBatches)
      .where(
        and(
          eq(productionBatches.status, 'brewing'),
          or(
            eq(productionBatches.status, 'fermenting'),
            eq(productionBatches.status, 'conditioning')
          )
        )
      )
      .orderBy(asc(productionBatches.startDate));
  }

  // Containers
  async getContainers(): Promise<Container[]> {
    return await db.select().from(containers).orderBy(desc(containers.createdAt));
  }

  async getContainer(id: number): Promise<Container | undefined> {
    const [container] = await db.select().from(containers).where(eq(containers.id, id));
    return container || undefined;
  }

  async getContainerByContainerId(containerId: string): Promise<Container | undefined> {
    const [container] = await db.select().from(containers).where(eq(containers.containerId, containerId));
    return container || undefined;
  }

  async createContainer(container: InsertContainer): Promise<Container> {
    const [newContainer] = await db.insert(containers).values(container).returning();
    return newContainer;
  }

  async updateContainer(id: number, container: Partial<InsertContainer>): Promise<Container> {
    const [updatedContainer] = await db
      .update(containers)
      .set({ ...container, updatedAt: new Date() })
      .where(eq(containers.id, id))
      .returning();
    return updatedContainer;
  }

  async deleteContainer(id: number): Promise<void> {
    await db.delete(containers).where(eq(containers.id, id));
  }

  async getOverdueContainers(): Promise<Container[]> {
    const now = new Date();
    return await db
      .select()
      .from(containers)
      .where(
        and(
          eq(containers.status, 'delivered'),
          lte(containers.expectedReturnDate, now)
        )
      )
      .orderBy(asc(containers.expectedReturnDate));
  }

  async getContainersByCustomer(customerId: number): Promise<Container[]> {
    return await db
      .select()
      .from(containers)
      .where(eq(containers.customerId, customerId))
      .orderBy(desc(containers.createdAt));
  }

  // Inventory
  async getInventory(): Promise<Inventory[]> {
    return await db.select().from(inventory).orderBy(asc(inventory.itemName));
  }

  async getInventoryItem(id: number): Promise<Inventory | undefined> {
    const [item] = await db.select().from(inventory).where(eq(inventory.id, id));
    return item || undefined;
  }

  async createInventoryItem(item: InsertInventory): Promise<Inventory> {
    const [newItem] = await db.insert(inventory).values(item).returning();
    return newItem;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory> {
    const [updatedItem] = await db
      .update(inventory)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(inventory.id, id))
      .returning();
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<void> {
    await db.delete(inventory).where(eq(inventory.id, id));
  }

  async getLowStockItems(): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(lte(inventory.currentStock, inventory.minimumStock))
      .orderBy(asc(inventory.itemName));
  }

  // Sales Visits
  async getSalesVisits(): Promise<SalesVisit[]> {
    return await db.select().from(salesVisits).orderBy(desc(salesVisits.scheduledDate));
  }

  async getSalesVisit(id: number): Promise<SalesVisit | undefined> {
    const [visit] = await db.select().from(salesVisits).where(eq(salesVisits.id, id));
    return visit || undefined;
  }

  async getSalesVisitsByCustomer(customerId: number): Promise<SalesVisit[]> {
    return await db
      .select()
      .from(salesVisits)
      .where(eq(salesVisits.customerId, customerId))
      .orderBy(desc(salesVisits.scheduledDate));
  }

  async createSalesVisit(visit: InsertSalesVisit): Promise<SalesVisit> {
    const [newVisit] = await db.insert(salesVisits).values(visit).returning();
    return newVisit;
  }

  async updateSalesVisit(id: number, visit: Partial<InsertSalesVisit>): Promise<SalesVisit> {
    const [updatedVisit] = await db
      .update(salesVisits)
      .set({ ...visit, updatedAt: new Date() })
      .where(eq(salesVisits.id, id))
      .returning();
    return updatedVisit;
  }

  async deleteSalesVisit(id: number): Promise<void> {
    await db.delete(salesVisits).where(eq(salesVisits.id, id));
  }

  async getUpcomingSalesVisits(): Promise<SalesVisit[]> {
    const now = new Date();
    const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return await db
      .select()
      .from(salesVisits)
      .where(
        and(
          eq(salesVisits.status, 'scheduled'),
          gte(salesVisits.scheduledDate, now),
          lte(salesVisits.scheduledDate, weekFromNow)
        )
      )
      .orderBy(asc(salesVisits.scheduledDate));
  }

  // Duty Calculations
  async getDutyCalculations(): Promise<DutyCalculation[]> {
    return await db.select().from(dutyCalculations).orderBy(desc(dutyCalculations.createdAt));
  }

  async getDutyCalculation(id: number): Promise<DutyCalculation | undefined> {
    const [calculation] = await db.select().from(dutyCalculations).where(eq(dutyCalculations.id, id));
    return calculation || undefined;
  }

  async createDutyCalculation(calculation: InsertDutyCalculation): Promise<DutyCalculation> {
    const [newCalculation] = await db.insert(dutyCalculations).values(calculation).returning();
    return newCalculation;
  }

  async updateDutyCalculation(id: number, calculation: Partial<InsertDutyCalculation>): Promise<DutyCalculation> {
    const [updatedCalculation] = await db
      .update(dutyCalculations)
      .set(calculation)
      .where(eq(dutyCalculations.id, id))
      .returning();
    return updatedCalculation;
  }

  async deleteDutyCalculation(id: number): Promise<void> {
    await db.delete(dutyCalculations).where(eq(dutyCalculations.id, id));
  }

  async getDutyCalculationsByPeriod(period: string): Promise<DutyCalculation[]> {
    return await db
      .select()
      .from(dutyCalculations)
      .where(eq(dutyCalculations.period, period))
      .orderBy(asc(dutyCalculations.createdAt));
  }

  // Analytics
  async getDashboardMetrics(): Promise<{
    totalCustomers: number;
    activeBatches: number;
    monthlyRevenue: number;
    containersOut: number;
    overdueContainers: number;
  }> {
    const [totalCustomersResult] = await db
      .select({ count: count() })
      .from(customers)
      .where(eq(customers.status, 'active'));

    const [activeBatchesResult] = await db
      .select({ count: count() })
      .from(productionBatches)
      .where(
        or(
          eq(productionBatches.status, 'brewing'),
          eq(productionBatches.status, 'fermenting'),
          eq(productionBatches.status, 'conditioning')
        )
      );

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const [monthlyRevenueResult] = await db
      .select({ total: sum(orders.totalAmount) })
      .from(orders)
      .where(
        and(
          gte(orders.createdAt, thirtyDaysAgo),
          eq(orders.status, 'delivered')
        )
      );

    const [containersOutResult] = await db
      .select({ count: count() })
      .from(containers)
      .where(
        or(
          eq(containers.status, 'out_for_delivery'),
          eq(containers.status, 'delivered')
        )
      );

    const [overdueContainersResult] = await db
      .select({ count: count() })
      .from(containers)
      .where(
        and(
          eq(containers.status, 'delivered'),
          lte(containers.expectedReturnDate, new Date())
        )
      );

    return {
      totalCustomers: totalCustomersResult.count,
      activeBatches: activeBatchesResult.count,
      monthlyRevenue: Number(monthlyRevenueResult.total || 0),
      containersOut: containersOutResult.count,
      overdueContainers: overdueContainersResult.count,
    };
  }

  async getSalesData(days: number): Promise<{ date: string; amount: number }[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const salesData = await db
      .select({
        date: orders.createdAt,
        amount: orders.totalAmount,
      })
      .from(orders)
      .where(
        and(
          gte(orders.createdAt, startDate),
          eq(orders.status, 'delivered')
        )
      )
      .orderBy(asc(orders.createdAt));

    return salesData.map(item => ({
      date: item.date?.toISOString().split('T')[0] || '',
      amount: Number(item.amount || 0),
    }));
  }
}

export const storage = new DatabaseStorage();
