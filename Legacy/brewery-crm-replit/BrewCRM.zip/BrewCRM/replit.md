# BrewCRM - Brewery Management System

## Overview

BrewCRM is a comprehensive brewery management system built with modern web technologies. The application provides a complete solution for managing brewery operations including customer relationships, production tracking, sales and orders, container management, inventory control, distribution, and duty calculations.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom brewery-themed color palette
- **State Management**: React Query (@tanstack/react-query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions

### Development Architecture
- **Monorepo Structure**: Shared schema between client and server
- **Build System**: ESBuild for server bundling, Vite for client bundling
- **Development Server**: Vite dev server with HMR and Express API integration
- **Environment**: Replit-optimized with cartographer plugin for development

## Key Components

### Core Business Modules
1. **Customer Management**: Complete CRM functionality with customer types, contact details, and relationship tracking
2. **Production Management**: Batch tracking, brewing process management, and production status monitoring
3. **Sales & Orders**: Order processing, sales tracking, and revenue management
4. **Container Tracking**: Keg and container lifecycle management with QR code support
5. **Inventory Management**: Stock tracking, minimum threshold alerts, and supplier management
6. **Distribution**: Delivery scheduling and route optimization
7. **Duty Calculations**: HMRC compliance and duty calculation automation
8. **Analytics**: Business intelligence and reporting dashboards

### Technical Components
- **Database Layer**: Drizzle ORM with type-safe queries and schema validation
- **API Layer**: RESTful endpoints with Express.js middleware
- **Authentication**: Session-based authentication with PostgreSQL storage
- **Validation**: Zod schemas for runtime type checking and validation
- **Error Handling**: Centralized error handling with user-friendly messages
- **Logging**: Request/response logging with performance metrics

## Data Flow

### Client-Server Communication
1. **API Requests**: HTTP requests through React Query with automatic caching and revalidation
2. **Data Fetching**: Optimistic updates with error handling and retry logic
3. **Real-time Updates**: Polling-based updates for critical data
4. **Form Submissions**: Validated submissions with immediate feedback

### Database Operations
1. **Read Operations**: Optimized queries with proper indexing and joins
2. **Write Operations**: Transactional operations with rollback support
3. **Schema Management**: Version-controlled migrations with Drizzle Kit
4. **Data Validation**: Schema-level and application-level validation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Modern TypeScript ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/react-***: Accessible UI components
- **react-hook-form**: Form management
- **zod**: Runtime type validation
- **tailwindcss**: Utility-first CSS framework

### Development Dependencies
- **tsx**: TypeScript execution for development
- **vite**: Build tool and development server
- **esbuild**: Fast JavaScript bundler
- **@replit/vite-plugin-***: Replit-specific development tools

## Deployment Strategy

### Production Build
- **Client Build**: Vite production build with code splitting and optimization
- **Server Build**: ESBuild bundle with external dependencies
- **Asset Optimization**: Automatic compression and caching headers
- **Environment Variables**: Secure configuration management

### Database Deployment
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Migrations**: Automated schema migrations with Drizzle Kit
- **Backup Strategy**: Automated backups through Neon platform
- **Monitoring**: Connection monitoring and performance tracking

### Runtime Environment
- **Node.js**: Production-ready Express server
- **Static Assets**: Optimized serving of client-side assets
- **Session Management**: PostgreSQL-backed session storage
- **Error Monitoring**: Centralized error logging and monitoring

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 04, 2025. Initial setup