import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { insertProductionBatchSchema } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { generateBatchNumber } from '@/lib/utils';
import type { ProductionBatch } from '@shared/schema';

interface ProductionFormProps {
  batch?: ProductionBatch;
  onSuccess: () => void;
}

export default function ProductionForm({ batch, onSuccess }: ProductionFormProps) {
  const { toast } = useToast();
  
  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const selectedProduct = products.find((p: any) => p.id === (batch?.productId || 0));
  
  const form = useForm({
    resolver: zodResolver(insertProductionBatchSchema.extend({
      estimatedFinishDate: insertProductionBatchSchema.shape.estimatedFinishDate.optional(),
      actualFinishDate: insertProductionBatchSchema.shape.actualFinishDate.optional(),
    })),
    defaultValues: {
      batchNumber: batch?.batchNumber || generateBatchNumber(selectedProduct?.type || 'BEER'),
      productId: batch?.productId || 0,
      status: batch?.status || 'brewing',
      startDate: batch?.startDate ? new Date(batch.startDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
      estimatedFinishDate: batch?.estimatedFinishDate ? new Date(batch.estimatedFinishDate).toISOString().split('T')[0] : '',
      actualFinishDate: batch?.actualFinishDate ? new Date(batch.actualFinishDate).toISOString().split('T')[0] : '',
      volume: batch?.volume || '',
      notes: batch?.notes || '',
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/production-batches', data);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Production batch created successfully',
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to create production batch',
        variant: 'destructive',
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('PUT', `/api/production-batches/${batch!.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Production batch updated successfully',
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update production batch',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: any) => {
    const payload = {
      ...data,
      productId: parseInt(data.productId),
      volume: data.volume ? parseFloat(data.volume) : null,
      estimatedFinishDate: data.estimatedFinishDate ? new Date(data.estimatedFinishDate).toISOString() : null,
      actualFinishDate: data.actualFinishDate ? new Date(data.actualFinishDate).toISOString() : null,
    };

    if (batch) {
      updateMutation.mutate(payload);
    } else {
      createMutation.mutate(payload);
    }
  };

  // Auto-generate batch number when product changes
  const handleProductChange = (productId: string) => {
    const product = products.find((p: any) => p.id === parseInt(productId));
    if (product && !batch) {
      form.setValue('batchNumber', generateBatchNumber(product.type || 'BEER'));
    }
    form.setValue('productId', parseInt(productId));
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="batchNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Batch Number</FormLabel>
                <FormControl>
                  <Input placeholder="Batch number" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="productId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Product</FormLabel>
                <Select
                  onValueChange={handleProductChange}
                  defaultValue={field.value ? field.value.toString() : ''}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {products.map((product: any) => (
                      <SelectItem key={product.id} value={product.id.toString()}>
                        {product.name} ({product.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="brewing">Brewing</SelectItem>
                    <SelectItem value="fermenting">Fermenting</SelectItem>
                    <SelectItem value="conditioning">Conditioning</SelectItem>
                    <SelectItem value="packaging">Packaging</SelectItem>
                    <SelectItem value="finished">Finished</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="volume"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Volume (Litres)</FormLabel>
                <FormControl>
                  <Input type="number" step="0.01" placeholder="0.00" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="estimatedFinishDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Estimated Finish Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="actualFinishDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Actual Finish Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea placeholder="Production notes, quality observations, etc..." {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3">
          <Button
            type="submit"
            className="bg-brewery-amber hover:bg-brewery-brown"
            disabled={createMutation.isPending || updateMutation.isPending}
          >
            {batch ? 'Update Batch' : 'Create Batch'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
