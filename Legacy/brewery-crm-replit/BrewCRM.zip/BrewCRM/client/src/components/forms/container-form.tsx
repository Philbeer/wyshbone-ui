import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { insertContainerSchema } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { generateContainerId } from '@/lib/utils';
import type { Container } from '@shared/schema';

interface ContainerFormProps {
  container?: Container;
  onSuccess: () => void;
}

export default function ContainerForm({ container, onSuccess }: ContainerFormProps) {
  const { toast } = useToast();
  
  const form = useForm({
    resolver: zodResolver(insertContainerSchema.extend({
      deliveryDate: insertContainerSchema.shape.deliveryDate.optional(),
      expectedReturnDate: insertContainerSchema.shape.expectedReturnDate.optional(),
      actualReturnDate: insertContainerSchema.shape.actualReturnDate.optional(),
      productId: insertContainerSchema.shape.productId.optional(),
      batchId: insertContainerSchema.shape.batchId.optional(),
      customerId: insertContainerSchema.shape.customerId.optional(),
    })),
    defaultValues: {
      containerId: container?.containerId || generateContainerId('KEG'),
      type: container?.type || 'keg',
      size: container?.size || '50L',
      status: container?.status || 'in_stock',
      productId: container?.productId || undefined,
      batchId: container?.batchId || undefined,
      customerId: container?.customerId || undefined,
      location: container?.location || 'Warehouse',
      deliveryDate: container?.deliveryDate ? new Date(container.deliveryDate).toISOString().split('T')[0] : '',
      expectedReturnDate: container?.expectedReturnDate ? new Date(container.expectedReturnDate).toISOString().split('T')[0] : '',
      actualReturnDate: container?.actualReturnDate ? new Date(container.actualReturnDate).toISOString().split('T')[0] : '',
      qrCode: container?.qrCode || '',
    },
  });

  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['/api/customers'],
    queryFn: async () => {
      const response = await fetch('/api/customers');
      if (!response.ok) throw new Error('Failed to fetch customers');
      return response.json();
    },
  });

  const { data: batches = [] } = useQuery({
    queryKey: ['/api/production-batches'],
    queryFn: async () => {
      const response = await fetch('/api/production-batches');
      if (!response.ok) throw new Error('Failed to fetch production batches');
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('POST', '/api/containers', data);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Container created successfully',
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to create container',
        variant: 'destructive',
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest('PUT', `/api/containers/${container!.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: 'Container updated successfully',
      });
      onSuccess();
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update container',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: any) => {
    const payload = {
      ...data,
      productId: data.productId ? parseInt(data.productId) : null,
      batchId: data.batchId ? parseInt(data.batchId) : null,
      customerId: data.customerId ? parseInt(data.customerId) : null,
      deliveryDate: data.deliveryDate ? new Date(data.deliveryDate).toISOString() : null,
      expectedReturnDate: data.expectedReturnDate ? new Date(data.expectedReturnDate).toISOString() : null,
      actualReturnDate: data.actualReturnDate ? new Date(data.actualReturnDate).toISOString() : null,
    };

    if (container) {
      updateMutation.mutate(payload);
    } else {
      createMutation.mutate(payload);
    }
  };

  // Auto-generate container ID when type changes
  const handleTypeChange = (type: string) => {
    if (!container) {
      form.setValue('containerId', generateContainerId(type));
    }
    form.setValue('type', type);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="containerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Container ID</FormLabel>
                <FormControl>
                  <Input placeholder="Container ID" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Container Type</FormLabel>
                <Select onValueChange={handleTypeChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select container type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="keg">Keg</SelectItem>
                    <SelectItem value="cask">Cask</SelectItem>
                    <SelectItem value="bottle">Bottle</SelectItem>
                    <SelectItem value="can">Can</SelectItem>
                    <SelectItem value="case">Case</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="size"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Size</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="9L">9L</SelectItem>
                    <SelectItem value="20L">20L</SelectItem>
                    <SelectItem value="30L">30L</SelectItem>
                    <SelectItem value="50L">50L</SelectItem>
                    <SelectItem value="330ml">330ml</SelectItem>
                    <SelectItem value="500ml">500ml</SelectItem>
                    <SelectItem value="24x330ml">24x330ml Case</SelectItem>
                    <SelectItem value="12x500ml">12x500ml Case</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="in_stock">In Stock</SelectItem>
                    <SelectItem value="out_for_delivery">Out for Delivery</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                    <SelectItem value="empty">Empty</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="productId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Product (Optional)</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select product" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">None (Empty)</SelectItem>
                    {products.map((product: any) => (
                      <SelectItem key={product.id} value={product.id.toString()}>
                        {product.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="customerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer (Optional)</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value?.toString()}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">None (In Warehouse)</SelectItem>
                    {customers.map((customer: any) => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input placeholder="Current location" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="deliveryDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Delivery Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="expectedReturnDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expected Return Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="actualReturnDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Actual Return Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="qrCode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>QR Code</FormLabel>
              <FormControl>
                <Input placeholder="QR code data (optional)" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3">
          <Button
            type="submit"
            className="bg-brewery-amber hover:bg-brewery-brown"
            disabled={createMutation.isPending || updateMutation.isPending}
          >
            {container ? 'Update Container' : 'Create Container'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
