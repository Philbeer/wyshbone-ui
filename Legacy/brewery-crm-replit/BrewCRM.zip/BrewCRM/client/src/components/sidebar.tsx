import { Link, useLocation } from "wouter";
import { 
  Gauge, 
  Users, 
  Factory, 
  TrendingUp, 
  Package, 
  Warehouse, 
  Truck, 
  BarChart3, 
  PoundSterling,
  Beer
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: Gauge },
  { name: "Customers", href: "/customers", icon: Users },
  { name: "Production", href: "/production", icon: Factory },
  { name: "Sales & Orders", href: "/orders", icon: TrendingUp },
  { name: "Container Tracking", href: "/containers", icon: Package },
  { name: "Inventory", href: "/inventory", icon: Warehouse },
  { name: "Distribution", href: "/distribution", icon: Truck },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Duty Calculator", href: "/duty", icon: PoundSterling },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden md:flex md:w-64 md:flex-col">
      <div className="flex flex-col flex-grow pt-5 bg-white border-r border-gray-200">
        <div className="flex items-center flex-shrink-0 px-4">
          <div className="flex items-center">
            <Beer className="h-8 w-8 text-brewery-amber mr-3" />
            <h1 className="text-xl font-bold text-gray-900">BrewCRM</h1>
          </div>
        </div>
        <div className="mt-8 flex-grow flex flex-col">
          <nav className="flex-1 px-2 space-y-1">
            {navigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                    isActive
                      ? "bg-brewery-amber text-white"
                      : "text-gray-700 hover:bg-gray-50"
                  )}
                >
                  <item.icon className="mr-3 h-5 w-5 flex-shrink-0" />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </div>
  );
}
