import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from 'lucide-react';
import { Link } from 'wouter';
import { formatDateTime } from '@/lib/utils';

export default function UpcomingVisits() {
  const { data: visits, isLoading, error } = useQuery({
    queryKey: ['/api/sales-visits/upcoming'],
    queryFn: async () => {
      const response = await fetch('/api/sales-visits/upcoming');
      if (!response.ok) throw new Error('Failed to fetch upcoming visits');
      return response.json();
    },
  });

  const { data: customers } = useQuery({
    queryKey: ['/api/customers'],
    queryFn: async () => {
      const response = await fetch('/api/customers');
      if (!response.ok) throw new Error('Failed to fetch customers');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Upcoming Visits</CardTitle>
            <div className="h-8 w-16 bg-gray-200 rounded animate-pulse"></div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center p-3 border border-gray-200 rounded-lg animate-pulse">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-32"></div>
                  <div className="h-3 bg-gray-200 rounded w-24"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Upcoming Visits</CardTitle>
            <Button variant="outline" size="sm">
              Schedule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center text-red-500">
            Failed to load upcoming visits
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!visits || visits.length === 0) {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Upcoming Visits</CardTitle>
            <Button variant="outline" size="sm">
              Schedule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500">
            No upcoming visits scheduled
          </div>
        </CardContent>
      </Card>
    );
  }

  const getCustomerName = (customerId: number) => {
    const customer = customers?.find((c: any) => c.id === customerId);
    return customer?.name || 'Unknown Customer';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Upcoming Visits</CardTitle>
          <Button variant="outline" size="sm">
            Schedule
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {visits.map((visit: any) => (
            <div key={visit.id} className="flex items-center p-3 border border-gray-200 rounded-lg">
              <div className="w-10 h-10 bg-brewery-amber rounded-full flex items-center justify-center">
                <Calendar className="h-5 w-5 text-white" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-900">
                  {getCustomerName(visit.customerId)}
                </p>
                <p className="text-xs text-gray-500">
                  {formatDateTime(visit.scheduledDate)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
