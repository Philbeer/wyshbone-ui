import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Clock, Info } from 'lucide-react';

export default function Alerts() {
  const { data: lowStock } = useQuery({
    queryKey: ['/api/inventory/low-stock'],
    queryFn: async () => {
      const response = await fetch('/api/inventory/low-stock');
      if (!response.ok) throw new Error('Failed to fetch low stock items');
      return response.json();
    },
  });

  const { data: overdueContainers } = useQuery({
    queryKey: ['/api/containers/overdue'],
    queryFn: async () => {
      const response = await fetch('/api/containers/overdue');
      if (!response.ok) throw new Error('Failed to fetch overdue containers');
      return response.json();
    },
  });

  const { data: activeBatches } = useQuery({
    queryKey: ['/api/production-batches/active'],
    queryFn: async () => {
      const response = await fetch('/api/production-batches/active');
      if (!response.ok) throw new Error('Failed to fetch active batches');
      return response.json();
    },
  });

  const alerts = [];

  // Add low stock alerts
  if (lowStock && lowStock.length > 0) {
    alerts.push({
      type: 'warning',
      icon: AlertTriangle,
      title: 'Low Stock Alert',
      message: `${lowStock.length} item${lowStock.length > 1 ? 's' : ''} below minimum threshold`,
      color: 'red',
    });
  }

  // Add overdue container alerts
  if (overdueContainers && overdueContainers.length > 0) {
    alerts.push({
      type: 'warning',
      icon: Clock,
      title: 'Overdue Containers',
      message: `${overdueContainers.length} container${overdueContainers.length > 1 ? 's' : ''} overdue`,
      color: 'yellow',
    });
  }

  // Add QC test alerts for active batches
  if (activeBatches && activeBatches.length > 0) {
    const batchesNeedingAttention = activeBatches.filter((batch: any) => 
      batch.status === 'fermenting' || batch.status === 'conditioning'
    );
    
    if (batchesNeedingAttention.length > 0) {
      alerts.push({
        type: 'info',
        icon: Info,
        title: 'QC Tests Due',
        message: `${batchesNeedingAttention.length} batch${batchesNeedingAttention.length > 1 ? 'es' : ''} may require testing`,
        color: 'blue',
      });
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alerts & Notifications</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.length === 0 ? (
            <div className="text-center text-gray-500">
              No alerts at this time
            </div>
          ) : (
            alerts.map((alert, index) => (
              <div 
                key={index} 
                className={`flex items-start p-3 border rounded-lg ${
                  alert.color === 'red' ? 'bg-red-50 border-red-200' :
                  alert.color === 'yellow' ? 'bg-yellow-50 border-yellow-200' :
                  'bg-blue-50 border-blue-200'
                }`}
              >
                <alert.icon className={`mt-0.5 mr-3 h-5 w-5 ${
                  alert.color === 'red' ? 'text-red-500' :
                  alert.color === 'yellow' ? 'text-yellow-500' :
                  'text-blue-500'
                }`} />
                <div>
                  <p className={`text-sm font-medium ${
                    alert.color === 'red' ? 'text-red-900' :
                    alert.color === 'yellow' ? 'text-yellow-900' :
                    'text-blue-900'
                  }`}>
                    {alert.title}
                  </p>
                  <p className={`text-xs ${
                    alert.color === 'red' ? 'text-red-700' :
                    alert.color === 'yellow' ? 'text-yellow-700' :
                    'text-blue-700'
                  }`}>
                    {alert.message}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
