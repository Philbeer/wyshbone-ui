import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Factory, PoundSterling, Package } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

export default function MetricsCards() {
  const { data: metrics, isLoading, error } = useQuery({
    queryKey: ['/api/dashboard/metrics'],
    queryFn: async () => {
      const response = await fetch('/api/dashboard/metrics');
      if (!response.ok) throw new Error('Failed to fetch metrics');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                  <div className="h-8 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-red-500">
              Failed to load metrics
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-gray-500">
              No metrics available
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Customers</p>
              <p className="text-2xl font-bold text-gray-900">{metrics.totalCustomers}</p>
            </div>
            <div className="p-3 bg-brewery-amber bg-opacity-10 rounded-full">
              <Users className="h-6 w-6 text-brewery-amber" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-green-600">Active accounts</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Batches</p>
              <p className="text-2xl font-bold text-gray-900">{metrics.activeBatches}</p>
            </div>
            <div className="p-3 bg-brewery-gold bg-opacity-10 rounded-full">
              <Factory className="h-6 w-6 text-brewery-gold" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-600">Currently brewing</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Monthly Revenue</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(metrics.monthlyRevenue)}
              </p>
            </div>
            <div className="p-3 bg-green-100 rounded-full">
              <PoundSterling className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-green-600">Last 30 days</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Containers Out</p>
              <p className="text-2xl font-bold text-gray-900">{metrics.containersOut}</p>
            </div>
            <div className="p-3 bg-brewery-blue bg-opacity-10 rounded-full">
              <Package className="h-6 w-6 text-brewery-blue" />
            </div>
          </div>
          <div className="mt-4">
            <span className="text-sm text-red-600">
              {metrics.overdueContainers} overdue returns
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
