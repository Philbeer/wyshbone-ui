import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Beer } from 'lucide-react';
import { getStatusColor } from '@/lib/utils';

export default function ProductionStatus() {
  const { data: batches, isLoading, error } = useQuery({
    queryKey: ['/api/production-batches/active'],
    queryFn: async () => {
      const response = await fetch('/api/production-batches/active');
      if (!response.ok) throw new Error('Failed to fetch production batches');
      return response.json();
    },
  });

  const { data: products } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Production Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg animate-pulse">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-32"></div>
                    <div className="h-3 bg-gray-200 rounded w-24"></div>
                  </div>
                </div>
                <div className="h-6 bg-gray-200 rounded w-20"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Production Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-red-500">
            Failed to load production status
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!batches || batches.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Production Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500">
            No active production batches
          </div>
        </CardContent>
      </Card>
    );
  }

  const getProductName = (productId: number) => {
    const product = products?.find((p: any) => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Production Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {batches.map((batch: any) => (
            <div key={batch.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-brewery-amber rounded-full flex items-center justify-center">
                  <Beer className="h-5 w-5 text-white" />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">
                    {getProductName(batch.productId)} - {batch.batchNumber}
                  </p>
                  <p className="text-xs text-gray-500">
                    {batch.status === 'brewing' && 'Currently brewing'}
                    {batch.status === 'fermenting' && 'Fermenting'}
                    {batch.status === 'conditioning' && 'Conditioning'}
                  </p>
                </div>
              </div>
              <Badge className={getStatusColor(batch.status)}>
                {batch.status.replace('_', ' ')}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
