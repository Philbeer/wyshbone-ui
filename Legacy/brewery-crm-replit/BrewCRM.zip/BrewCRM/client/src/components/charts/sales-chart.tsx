import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { formatCurrency } from '@/lib/utils';

interface SalesChartProps {
  days?: number;
}

export default function SalesChart({ days = 30 }: SalesChartProps) {
  const { data: salesData, isLoading, error } = useQuery({
    queryKey: ['/api/dashboard/sales-data', days],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/sales-data?days=${days}`);
      if (!response.ok) throw new Error('Failed to fetch sales data');
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="text-sm text-gray-500">Loading sales data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="text-sm text-red-500">Failed to load sales data</div>
      </div>
    );
  }

  if (!salesData || salesData.length === 0) {
    return (
      <div className="w-full h-64 flex items-center justify-center">
        <div className="text-sm text-gray-500">No sales data available</div>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={salesData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis 
          dataKey="date" 
          tick={{ fontSize: 12 }}
          tickFormatter={(value) => new Date(value).toLocaleDateString('en-GB', { 
            month: 'short', 
            day: 'numeric' 
          })}
        />
        <YAxis 
          tick={{ fontSize: 12 }}
          tickFormatter={(value) => formatCurrency(value)}
        />
        <Tooltip 
          formatter={(value) => [formatCurrency(Number(value)), 'Sales']}
          labelFormatter={(label) => new Date(label).toLocaleDateString('en-GB')}
        />
        <Line 
          type="monotone" 
          dataKey="amount" 
          stroke="var(--brewery-amber)" 
          strokeWidth={2}
          dot={{ fill: 'var(--brewery-amber)', strokeWidth: 2 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
