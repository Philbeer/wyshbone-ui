import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, QrCode, Package, Truck, Warehouse, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import ContainerForm from '@/components/forms/container-form';
import { formatDate, getStatusColor } from '@/lib/utils';

export default function Containers() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingContainer, setEditingContainer] = useState<any>(null);
  const [trackingId, setTrackingId] = useState('');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: containers = [], isLoading, error } = useQuery({
    queryKey: ['/api/containers'],
    queryFn: async () => {
      const response = await fetch('/api/containers');
      if (!response.ok) throw new Error('Failed to fetch containers');
      return response.json();
    },
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['/api/customers'],
    queryFn: async () => {
      const response = await fetch('/api/customers');
      if (!response.ok) throw new Error('Failed to fetch customers');
      return response.json();
    },
  });

  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const deleteContainerMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/containers/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete container');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/containers'] });
      toast({
        title: 'Success',
        description: 'Container deleted successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to delete container',
        variant: 'destructive',
      });
    },
  });

  const trackContainerMutation = useMutation({
    mutationFn: async (containerId: string) => {
      const response = await fetch(`/api/containers/track/${containerId}`);
      if (!response.ok) throw new Error('Container not found');
      return response.json();
    },
    onSuccess: (container) => {
      toast({
        title: 'Container Found',
        description: `${container.containerId} - ${container.status}`,
      });
      setEditingContainer(container);
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Container not found',
        variant: 'destructive',
      });
    },
  });

  const handleTrackContainer = () => {
    if (trackingId.trim()) {
      trackContainerMutation.mutate(trackingId.trim());
      setTrackingId('');
    }
  };

  const filteredContainers = containers.filter((container: any) =>
    container.containerId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    container.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    container.status.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCustomerName = (customerId: number) => {
    const customer = customers.find((c: any) => c.id === customerId);
    return customer?.name || 'Warehouse';
  };

  const getProductName = (productId: number) => {
    const product = products.find((p: any) => p.id === productId);
    return product?.name || 'Empty';
  };

  const totalContainers = containers.length;
  const outForDelivery = containers.filter((c: any) => c.status === 'out_for_delivery').length;
  const inStock = containers.filter((c: any) => c.status === 'in_stock').length;
  const overdue = containers.filter((c: any) => {
    if (c.status === 'delivered' && c.expectedReturnDate) {
      return new Date(c.expectedReturnDate) < new Date();
    }
    return false;
  }).length;

  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Container Tracking</h1>
          <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Container Tracking</h1>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-red-500">
              Failed to load container data
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Container Tracking</h1>
        <div className="flex space-x-3">
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Enter container ID..."
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              className="w-48"
            />
            <Button
              onClick={handleTrackContainer}
              className="bg-brewery-amber hover:bg-brewery-brown"
            >
              <QrCode className="h-4 w-4 mr-2" />
              Track
            </Button>
          </div>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Add Container
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Container</DialogTitle>
              </DialogHeader>
              <ContainerForm
                onSuccess={() => {
                  setShowAddDialog(false);
                  queryClient.invalidateQueries({ queryKey: ['/api/containers'] });
                }}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Container Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Containers</p>
                <p className="text-2xl font-bold text-gray-900">{totalContainers}</p>
              </div>
              <Package className="h-8 w-8 text-gray-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-yellow-600">Out for Delivery</p>
                <p className="text-2xl font-bold text-yellow-900">{outForDelivery}</p>
              </div>
              <Truck className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-600">In Stock</p>
                <p className="text-2xl font-bold text-green-900">{inStock}</p>
              </div>
              <Warehouse className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-red-600">Overdue</p>
                <p className="text-2xl font-bold text-red-900">{overdue}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Container Management</CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search containers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Container ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contents
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Location
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Delivery Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredContainers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                      {searchQuery ? 'No containers found matching your search' : 'No containers available'}
                    </td>
                  </tr>
                ) : (
                  filteredContainers.map((container: any) => (
                    <tr key={container.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <QrCode className="h-5 w-5 text-brewery-amber mr-3" />
                          <span className="text-sm font-medium text-gray-900">
                            {container.containerId}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {container.type} ({container.size})
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {container.productId ? getProductName(container.productId) : 'Empty'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {container.customerId ? getCustomerName(container.customerId) : 'Warehouse'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge className={getStatusColor(container.status)}>
                          {container.status.replace('_', ' ')}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {container.deliveryDate ? formatDate(container.deliveryDate) : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingContainer(container)}
                          className="text-brewery-amber hover:text-brewery-brown mr-3"
                        >
                          Track
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteContainerMutation.mutate(container.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {editingContainer && (
        <Dialog open={!!editingContainer} onOpenChange={() => setEditingContainer(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Container Details</DialogTitle>
            </DialogHeader>
            <ContainerForm
              container={editingContainer}
              onSuccess={() => {
                setEditingContainer(null);
                queryClient.invalidateQueries({ queryKey: ['/api/containers'] });
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
