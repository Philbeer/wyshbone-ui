import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Calculator, Download, PoundSterling, Calendar, FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, calculateDuty } from '@/lib/utils';

interface DutyFormProps {
  calculation?: any;
  onSuccess: () => void;
}

function DutyForm({ calculation, onSuccess }: DutyFormProps) {
  const [formData, setFormData] = useState({
    period: calculation?.period || new Date().toISOString().slice(0, 7), // YYYY-MM format
    productId: calculation?.productId || '',
    volumeProduced: calculation?.volumeProduced || '',
    volumeSold: calculation?.volumeSold || '',
    dutyRate: calculation?.dutyRate || '21.01',
    ullage: calculation?.ullage || '',
  });

  const { toast } = useToast();

  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch('/api/duty-calculations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create duty calculation');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'Duty calculation created successfully' });
      onSuccess();
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to create duty calculation', variant: 'destructive' });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch(`/api/duty-calculations/${calculation.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update duty calculation');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'Duty calculation updated successfully' });
      onSuccess();
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to update duty calculation', variant: 'destructive' });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const selectedProduct = products.find((p: any) => p.id === parseInt(formData.productId));
    const abv = Number(selectedProduct?.abv || 0);
    const volumeProduced = parseFloat(formData.volumeProduced) || 0;
    const volumeSold = parseFloat(formData.volumeSold) || 0;
    const ullage = parseFloat(formData.ullage) || 0;
    const dutyRate = parseFloat(formData.dutyRate) || 21.01;
    
    // Calculate duty owed (on volume sold)
    const dutyOwed = (volumeSold / 100) * abv * dutyRate - (ullage / 100) * abv * dutyRate;
    
    const data = {
      ...formData,
      productId: parseInt(formData.productId),
      volumeProduced,
      volumeSold,
      dutyRate,
      ullage,
      dutyOwed: Math.max(0, dutyOwed),
    };

    if (calculation) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Period (YYYY-MM)
          </label>
          <Input
            type="month"
            value={formData.period}
            onChange={(e) => setFormData({ ...formData, period: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Product
          </label>
          <select
            value={formData.productId}
            onChange={(e) => setFormData({ ...formData, productId: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-brewery-amber focus:border-transparent"
            required
          >
            <option value="">Select Product</option>
            {products.map((product: any) => (
              <option key={product.id} value={product.id}>
                {product.name} ({product.abv}% ABV)
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Volume Produced (HL)
          </label>
          <Input
            type="number"
            step="0.01"
            value={formData.volumeProduced}
            onChange={(e) => setFormData({ ...formData, volumeProduced: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Volume Sold (HL)
          </label>
          <Input
            type="number"
            step="0.01"
            value={formData.volumeSold}
            onChange={(e) => setFormData({ ...formData, volumeSold: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ullage/Wastage (HL)
          </label>
          <Input
            type="number"
            step="0.01"
            value={formData.ullage}
            onChange={(e) => setFormData({ ...formData, ullage: e.target.value })}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Duty Rate (£ per HL per % ABV)
        </label>
        <Input
          type="number"
          step="0.01"
          value={formData.dutyRate}
          onChange={(e) => setFormData({ ...formData, dutyRate: e.target.value })}
          required
        />
        <p className="text-xs text-gray-500 mt-1">
          Current UK beer duty rate: £21.01 per hectolitre per % ABV
        </p>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button
          type="submit"
          className="bg-brewery-amber hover:bg-brewery-brown"
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {calculation ? 'Update Calculation' : 'Calculate Duty'}
        </Button>
      </div>
    </form>
  );
}

export default function Duty() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingCalculation, setEditingCalculation] = useState<any>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: calculations = [], isLoading, error } = useQuery({
    queryKey: ['/api/duty-calculations'],
    queryFn: async () => {
      const response = await fetch('/api/duty-calculations');
      if (!response.ok) throw new Error('Failed to fetch duty calculations');
      return response.json();
    },
  });

  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await fetch('/api/products');
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const deleteCalculationMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/duty-calculations/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete duty calculation');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/duty-calculations'] });
      toast({
        title: 'Success',
        description: 'Duty calculation deleted successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to delete duty calculation',
        variant: 'destructive',
      });
    },
  });

  const filteredCalculations = calculations.filter((calc: any) =>
    calc.period.includes(searchQuery) ||
    getProductName(calc.productId).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getProductName = (productId: number) => {
    const product = products.find((p: any) => p.id === productId);
    return product?.name || 'Unknown Product';
  };

  // Calculate totals for current period
  const currentPeriod = new Date().toISOString().slice(0, 7);
  const currentPeriodCalculations = calculations.filter((calc: any) => 
    calc.period === currentPeriod
  );
  
  const totalDutyOwed = currentPeriodCalculations.reduce((total: number, calc: any) => 
    total + Number(calc.dutyOwed || 0), 0
  );
  
  const totalVolumeProduced = currentPeriodCalculations.reduce((total: number, calc: any) => 
    total + Number(calc.volumeProduced || 0), 0
  );
  
  const totalVolumeSold = currentPeriodCalculations.reduce((total: number, calc: any) => 
    total + Number(calc.volumeSold || 0), 0
  );

  if (isLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Duty Calculator</h1>
          <div className="h-10 w-32 bg-gray-200 rounded animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Duty Calculator</h1>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="text-center text-red-500">
              Failed to load duty calculations
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Duty Calculator</h1>
        <div className="flex space-x-3">
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-brewery-amber hover:bg-brewery-brown">
                <Calculator className="h-4 w-4 mr-2" />
                New Calculation
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Duty Calculation</DialogTitle>
              </DialogHeader>
              <DutyForm
                onSuccess={() => {
                  setShowAddDialog(false);
                  queryClient.invalidateQueries({ queryKey: ['/api/duty-calculations'] });
                }}
              />
            </DialogContent>
          </Dialog>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export TTB
          </Button>
        </div>
      </div>

      {/* Duty Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Duty Owed</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(totalDutyOwed)}
                </p>
              </div>
              <PoundSterling className="h-8 w-8 text-red-600" />
            </div>
            <div className="mt-2">
              <span className="text-xs text-gray-500">Current period ({currentPeriod})</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Volume Produced</p>
                <p className="text-2xl font-bold text-gray-900">
                  {totalVolumeProduced.toFixed(2)} HL
                </p>
              </div>
              <Calculator className="h-8 w-8 text-brewery-amber" />
            </div>
            <div className="mt-2">
              <span className="text-xs text-gray-500">This period</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Volume Sold</p>
                <p className="text-2xl font-bold text-gray-900">
                  {totalVolumeSold.toFixed(2)} HL
                </p>
              </div>
              <FileText className="h-8 w-8 text-brewery-blue" />
            </div>
            <div className="mt-2">
              <span className="text-xs text-gray-500">Dutiable volume</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Next Due Date</p>
                <p className="text-2xl font-bold text-gray-900">
                  {new Date(new Date().getFullYear(), new Date().getMonth() + 1, 7).getDate()}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-brewery-gold" />
            </div>
            <div className="mt-2">
              <span className="text-xs text-gray-500">
                {new Date(new Date().getFullYear(), new Date().getMonth() + 1, 7).toLocaleDateString('en-GB', { 
                  month: 'short', 
                  year: 'numeric' 
                })}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* UK Duty Information */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>UK Beer Duty Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Current Rates (2024)</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Beer (1.2% - 2.8% ABV): £8.42 per hectolitre per % ABV</li>
                <li>• Beer (2.8% - 7.5% ABV): £21.01 per hectolitre per % ABV</li>
                <li>• Beer (7.5%+ ABV): £28.50 per hectolitre per % ABV</li>
                <li>• Small Brewery Relief: Available for qualifying breweries</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-gray-900 mb-2">Payment Deadlines</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Monthly returns: 7th of following month</li>
                <li>• Quarterly returns: 7th day after quarter end</li>
                <li>• Annual returns: 7th day after year end</li>
                <li>• Late payment penalties apply</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Duty Calculations</CardTitle>
            <Input
              placeholder="Search by period or product..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64"
            />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Period
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Product
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Volume Produced
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Volume Sold
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ullage
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Duty Owed
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredCalculations.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-4 text-center text-gray-500">
                      {searchQuery ? 'No calculations found matching your search' : 'No duty calculations available'}
                    </td>
                  </tr>
                ) : (
                  filteredCalculations.map((calc: any) => (
                    <tr key={calc.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {calc.period}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {getProductName(calc.productId)}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {Number(calc.volumeProduced || 0).toFixed(2)} HL
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {Number(calc.volumeSold || 0).toFixed(2)} HL
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {Number(calc.ullage || 0).toFixed(2)} HL
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <span className="font-medium text-red-600">
                          {formatCurrency(Number(calc.dutyOwed || 0))}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingCalculation(calc)}
                          className="text-brewery-amber hover:text-brewery-brown mr-3"
                        >
                          Edit
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteCalculationMutation.mutate(calc.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          Delete
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {editingCalculation && (
        <Dialog open={!!editingCalculation} onOpenChange={() => setEditingCalculation(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Duty Calculation</DialogTitle>
            </DialogHeader>
            <DutyForm
              calculation={editingCalculation}
              onSuccess={() => {
                setEditingCalculation(null);
                queryClient.invalidateQueries({ queryKey: ['/api/duty-calculations'] });
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
