import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Truck, Route, MapPin, Clock, Package, Navigation } from 'lucide-react';
import { formatDate, formatCurrency, getStatusColor } from '@/lib/utils';

export default function Distribution() {
  const [searchQuery, setSearchQuery] = useState('');

  const { data: orders = [], isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/orders'],
    queryFn: async () => {
      const response = await fetch('/api/orders');
      if (!response.ok) throw new Error('Failed to fetch orders');
      return response.json();
    },
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['/api/customers'],
    queryFn: async () => {
      const response = await fetch('/api/customers');
      if (!response.ok) throw new Error('Failed to fetch customers');
      return response.json();
    },
  });

  const getCustomerName = (customerId: number) => {
    const customer = customers.find((c: any) => c.id === customerId);
    return customer?.name || 'Unknown Customer';
  };

  const getCustomerAddress = (customerId: number) => {
    const customer = customers.find((c: any) => c.id === customerId);
    if (!customer) return 'Unknown Address';
    return `${customer.address || ''} ${customer.city || ''} ${customer.postcode || ''}`.trim();
  };

  // Filter orders that are ready for delivery
  const deliveryOrders = orders.filter((order: any) => 
    order.status === 'confirmed' || order.status === 'pending'
  );

  const filteredOrders = deliveryOrders.filter((order: any) => {
    const customerName = getCustomerName(order.customerId).toLowerCase();
    const orderNumber = order.orderNumber.toLowerCase();
    const query = searchQuery.toLowerCase();
    return customerName.includes(query) || orderNumber.includes(query);
  });

  // Mock delivery routes (in a real app, this would come from a routing service)
  const deliveryRoutes = [
    {
      id: 1,
      name: 'London Central Route',
      driver: 'John Smith',
      vehicle: 'VAN-001',
      stops: 8,
      totalDistance: 45,
      estimatedTime: '4h 30m',
      status: 'in_progress',
      orders: deliveryOrders.slice(0, 3),
    },
    {
      id: 2,
      name: 'North London Route',
      driver: 'Sarah Johnson',
      vehicle: 'VAN-002',
      stops: 6,
      totalDistance: 38,
      estimatedTime: '3h 45m',
      status: 'planned',
      orders: deliveryOrders.slice(3, 6),
    },
    {
      id: 3,
      name: 'South East Route',
      driver: 'Mike Wilson',
      vehicle: 'TRUCK-001',
      stops: 12,
      totalDistance: 67,
      estimatedTime: '6h 15m',
      status: 'completed',
      orders: deliveryOrders.slice(6, 9),
    },
  ];

  const activeRoutes = deliveryRoutes.filter(route => route.status === 'in_progress').length;
  const plannedRoutes = deliveryRoutes.filter(route => route.status === 'planned').length;
  const completedToday = deliveryRoutes.filter(route => route.status === 'completed').length;
  const totalStops = deliveryRoutes.reduce((total, route) => total + route.stops, 0);

  if (ordersLoading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Distribution</h1>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Distribution</h1>
        <div className="flex space-x-3">
          <Button className="bg-brewery-amber hover:bg-brewery-brown">
            <Route className="h-4 w-4 mr-2" />
            Optimize Routes
          </Button>
          <Button variant="outline">
            <Navigation className="h-4 w-4 mr-2" />
            Plan Delivery
          </Button>
        </div>
      </div>

      {/* Distribution Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Routes</p>
                <p className="text-2xl font-bold text-gray-900">{activeRoutes}</p>
              </div>
              <Truck className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Planned Routes</p>
                <p className="text-2xl font-bold text-gray-900">{plannedRoutes}</p>
              </div>
              <Route className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed Today</p>
                <p className="text-2xl font-bold text-gray-900">{completedToday}</p>
              </div>
              <Package className="h-8 w-8 text-brewery-amber" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Stops</p>
                <p className="text-2xl font-bold text-gray-900">{totalStops}</p>
              </div>
              <MapPin className="h-8 w-8 text-brewery-gold" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Delivery Routes */}
        <Card>
          <CardHeader>
            <CardTitle>Delivery Routes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {deliveryRoutes.map((route) => (
                <div key={route.id} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-medium text-gray-900">{route.name}</h4>
                      <p className="text-sm text-gray-500">
                        Driver: {route.driver} • Vehicle: {route.vehicle}
                      </p>
                    </div>
                    <Badge className={getStatusColor(route.status)}>
                      {route.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 text-gray-400 mr-1" />
                      <span>{route.stops} stops</span>
                    </div>
                    <div className="flex items-center">
                      <Route className="h-4 w-4 text-gray-400 mr-1" />
                      <span>{route.totalDistance} miles</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 text-gray-400 mr-1" />
                      <span>{route.estimatedTime}</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-gray-100">
                    <p className="text-xs text-gray-500 mb-2">
                      Orders: {route.orders.length} delivery{route.orders.length !== 1 ? 'ies' : 'y'}
                    </p>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        View Route
                      </Button>
                      {route.status === 'planned' && (
                        <Button size="sm" className="bg-brewery-amber hover:bg-brewery-brown">
                          Start Route
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Orders Ready for Delivery */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Orders Ready for Delivery</CardTitle>
              <Input
                placeholder="Search orders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-48"
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {filteredOrders.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  {searchQuery ? 'No orders found matching your search' : 'No orders ready for delivery'}
                </div>
              ) : (
                filteredOrders.map((order: any) => (
                  <div key={order.id} className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">
                          {order.orderNumber}
                        </p>
                        <p className="text-sm text-gray-600">
                          {getCustomerName(order.customerId)}
                        </p>
                        <p className="text-xs text-gray-500">
                          {getCustomerAddress(order.customerId)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">
                          {formatCurrency(Number(order.totalAmount || 0))}
                        </p>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="mt-2 flex items-center justify-between">
                      <p className="text-xs text-gray-500">
                        Order Date: {formatDate(order.orderDate)}
                      </p>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          View
                        </Button>
                        <Button size="sm" className="bg-brewery-amber hover:bg-brewery-brown">
                          Add to Route
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fleet Management */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Fleet Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-gray-900">VAN-001</h4>
                  <p className="text-sm text-gray-500">Ford Transit</p>
                </div>
                <Badge className="bg-green-100 text-green-800">Available</Badge>
              </div>
              <div className="text-sm text-gray-600">
                <p>Capacity: 3.5 tonnes</p>
                <p>Driver: John Smith</p>
                <p>Last service: 15 days ago</p>
              </div>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-gray-900">VAN-002</h4>
                  <p className="text-sm text-gray-500">Mercedes Sprinter</p>
                </div>
                <Badge className="bg-blue-100 text-blue-800">On Route</Badge>
              </div>
              <div className="text-sm text-gray-600">
                <p>Capacity: 4.2 tonnes</p>
                <p>Driver: Sarah Johnson</p>
                <p>ETA: 2:30 PM</p>
              </div>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-medium text-gray-900">TRUCK-001</h4>
                  <p className="text-sm text-gray-500">DAF CF</p>
                </div>
                <Badge className="bg-yellow-100 text-yellow-800">Maintenance</Badge>
              </div>
              <div className="text-sm text-gray-600">
                <p>Capacity: 7.5 tonnes</p>
                <p>Driver: Mike Wilson</p>
                <p>Available: Tomorrow</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
