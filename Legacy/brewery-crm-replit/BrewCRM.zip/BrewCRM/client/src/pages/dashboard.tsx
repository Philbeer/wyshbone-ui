import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import MetricsCards from '@/components/dashboard/metrics-cards';
import SalesChart from '@/components/charts/sales-chart';
import ProductionStatus from '@/components/dashboard/production-status';
import RecentOrders from '@/components/dashboard/recent-orders';
import UpcomingVisits from '@/components/dashboard/upcoming-visits';
import Alerts from '@/components/dashboard/alerts';
import { useState } from 'react';

export default function Dashboard() {
  const [salesPeriod, setSalesPeriod] = useState('30');

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-8">
      <MetricsCards />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Sales Performance</CardTitle>
              <Select value={salesPeriod} onValueChange={setSalesPeriod}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                  <SelectItem value="365">Last year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <SalesChart days={parseInt(salesPeriod)} />
          </CardContent>
        </Card>

        <ProductionStatus />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <RecentOrders />
        <UpcomingVisits />
        <Alerts />
      </div>
    </div>
  );
}
