import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Customers from "@/pages/customers";
import Production from "@/pages/production";
import Orders from "@/pages/orders";
import Containers from "@/pages/containers";
import Inventory from "@/pages/inventory";
import Distribution from "@/pages/distribution";
import Analytics from "@/pages/analytics";
import Duty from "@/pages/duty";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import NotFound from "@/pages/not-found";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
          {children}
        </main>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/customers" component={Customers} />
      <Route path="/production" component={Production} />
      <Route path="/orders" component={Orders} />
      <Route path="/containers" component={Containers} />
      <Route path="/inventory" component={Inventory} />
      <Route path="/distribution" component={Distribution} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/duty" component={Duty} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Layout>
          <Router />
        </Layout>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
